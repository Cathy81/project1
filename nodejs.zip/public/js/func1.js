function addComments () {
	var input=document.getElementById("comments").value;
	window.alert(input);
}